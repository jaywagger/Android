insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'lee',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000001',1);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kim',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000001',5);

insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'lee',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000002',1);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kim',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000002',1);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000002',1);	
			
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'lee',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000003',1);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kim',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000003',10);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000004',2);	
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'lee',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000005',6);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kim',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000005',1);
			
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000006',20);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000007',4);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000008',11);	
			
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000009',15);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'kang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000010',1);
insert into TB_ORDER
values (to_char(sysdate,'yyyymmdd') ||100||ord_seq.nextval,
        'jang',50000,'김서연','010','서울','001','test','N',sysdate);
insert into TB_ORDER_PRODUCT 
values(to_char(sysdate,'yyyymmdd') ||100||ord_seq.currval,
			'PRD000000011',1);
			
			

commit;



















